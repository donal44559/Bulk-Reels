-- ============================================================
--  Comment Marketing Pro (2nd tool) — SUPABASE ALL-IN-ONE SETUP
--  Create a NEW Supabase project for this tool, open SQL Editor,
--  paste this WHOLE file, Run once. Done.
--
--  This gives the 2nd tool its OWN license database and its OWN
--  update channel, fully separated from the Reels tool:
--    1) tool_users + licenses (owner seed included)
--    2) admin_config (admin password)
--    3) app_versions (update system, seeded at 1.0.0)
--    4) SECURITY FIX applied (anon key can read/write nothing —
--       auth runs through SECURITY DEFINER RPCs)
--
--  Owner login seeded: username 'eusuf' / key 'EUSUF-OWNER-9K7X-MASTER-2026'
--  Admin panel default password: Abc123@#$Eusuf2026 (change it in Admin Panel)
-- ============================================================


-- ############ PART 1: SCHEMA + TABLES ############

-- ============================================================
-- Bulk Reels Upload Pro — Supabase schema (v2)
-- Run this ONCE in Supabase → SQL Editor → New query → Run
-- Safe to re-run: uses IF NOT EXISTS / ON CONFLICT
-- ============================================================

-- ---------- USERS TABLE ----------
create table if not exists public.tool_users (
  id                uuid primary key default gen_random_uuid(),
  username          text unique not null,
  activation_key    text unique not null,
  full_name         text default '',
  expires_at        timestamptz not null,
  is_blocked        boolean not null default false,
  notes             text default '',
  created_at        timestamptz not null default now(),
  last_seen_at      timestamptz,
  last_seen_ip      text default '',
  machine_id        text default ''
);

create index if not exists tool_users_username_idx on public.tool_users (lower(username));
create index if not exists tool_users_key_idx      on public.tool_users (activation_key);

-- ---------- ROW LEVEL SECURITY ----------
alter table public.tool_users enable row level security;

drop policy if exists "read own row"     on public.tool_users;
drop policy if exists "update last_seen"  on public.tool_users;

create policy "read own row"
  on public.tool_users for select
  using (true);

create policy "update last_seen"
  on public.tool_users for update
  using (true)
  with check (true);

-- ---------- SEED: OWNER ADMIN USER ----------
insert into public.tool_users (username, activation_key, full_name, expires_at, notes)
values (
  'eusuf',
  'EUSUF-OWNER-9K7X-MASTER-2026',
  'Eusuf Hasan (Owner)',
  now() + interval '10 years',
  'Owner account — do not delete'
)
on conflict (username) do update set
  activation_key = excluded.activation_key,
  expires_at     = excluded.expires_at,
  is_blocked     = false,
  notes          = excluded.notes;

-- ---------- ADMIN CONFIG TABLE ----------
create table if not exists public.admin_config (
  key   text primary key,
  value text not null
);

alter table public.admin_config enable row level security;

drop policy if exists "read admin config" on public.admin_config;
create policy "read admin config"
  on public.admin_config for select
  using (true);

-- Admin password: Abc123@#$Eusuf2026 (bcrypt hashed)
insert into public.admin_config (key, value)
values ('admin_password_hash', '$2b$10$PIYHxVGenfUWb4GoobVOJu76FNtuYY9Pi/67kNkmrIfJlYfOFzLu.')
on conflict (key) do update set value = excluded.value;

-- ============================================================
-- VERIFY:
--   select username, activation_key, expires_at, is_blocked from public.tool_users;
--   select * from public.admin_config;
-- ============================================================

-- ############ PART 2: ADMIN FLAG ############

-- ============================================================
-- Add is_admin flag to tool_users
-- Only users with is_admin=true see the Admin Panel in the UI
-- Run this ONCE in Supabase → SQL Editor
-- ============================================================

alter table public.tool_users
  add column if not exists is_admin boolean not null default false;

-- Mark the owner as admin
update public.tool_users
  set is_admin = true
  where username = 'eusuf';

-- Verify:
--   select username, is_admin, expires_at from public.tool_users;

-- ############ PART 3: UPDATE SYSTEM (seeded at 1.0.0) ############

-- ============================================================
-- Update / Version Management for Bulk Reels Upload Pro
-- Run this ONCE in Supabase → SQL Editor → New query → Run
-- ============================================================

create table if not exists public.app_versions (
  id            uuid primary key default gen_random_uuid(),
  version       text not null,                    -- e.g. "1.5.0" (semver)
  download_url  text not null,                    -- Google Drive / Mega direct link
  release_notes text default '',                  -- what's new
  is_force      boolean not null default false,   -- force user to update?
  min_version   text default '',                  -- if current < this, force
  published_at  timestamptz not null default now(),
  is_active     boolean not null default true     -- only active row is served
);

create index if not exists app_versions_active_idx
  on public.app_versions (is_active, published_at desc);

alter table public.app_versions enable row level security;

-- Anyone with anon key can READ the latest active version (public info)
drop policy if exists "read active version" on public.app_versions;
create policy "read active version"
  on public.app_versions for select
  using (true);

-- Seed the CURRENT version so no "update available" shows up right away
-- Change this whenever you release a new version — or use Admin Panel UI.
insert into public.app_versions (version, download_url, release_notes, is_force, is_active)
values (
  '1.0.0',
  'https://drive.google.com/your-installer-link-here',
  'Initial release with user/admin panel, activation system, and auto-comments.',
  false,
  true
)
on conflict do nothing;

-- ============================================================
-- VERIFY:
--   select version, is_active, is_force, published_at
--   from public.app_versions order by published_at desc;
-- ============================================================

-- ############ PART 4: SECURITY FIX (RLS + RPC) ############

-- ============================================================
-- Bulk Reels Upload Pro — SECURITY FIX (C1–C5)
-- Run this ONCE in Supabase → SQL Editor → New query → Run
-- Safe to re-run: everything uses IF EXISTS / OR REPLACE.
--
-- What this fixes (matches the security audit):
--   C1  tool_users SELECT was `using (true)`  → anyone with the anon key
--       could read ALL users' activation_key / expires_at / machine_id.
--       → ALL direct SELECT is now blocked; reads happen only through the
--         SECURITY DEFINER RPCs below (which return only safe fields —
--         activation_key is NEVER returned).
--   C2  tool_users UPDATE was `using (true) with check (true)` → anyone
--       could self-unlock expiry, unblock themselves, clear machine_id,
--       or edit OTHER users' rows.  → ALL direct UPDATE is now blocked;
--       last_seen/machine binding happens only inside the RPCs.
--   C4  admin_config (password hash) was anon-readable. → policy dropped;
--       the app reads it with the admin (service) client instead.
--   C5  app_versions had a live PLACEHOLDER row (fake Google Drive link).
--       → placeholder rows are deactivated by this script. Publishing a
--       new version from the Admin Panel also auto-deactivates old rows.
--   C3  (service key shipped inside the app) — the RLS fixes above are the
--       immediate stopgap: the anon key can no longer touch tool_users /
--       admin_config at all. The permanent fix is to move admin operations
--       into a Supabase Edge Function so the service key never ships with
--       the exe. Plan this as the next migration.
--
-- ⚠️ MIGRATION NOTE: after running this script, OLD builds (that read/
--    patch tool_users directly) will fail to authenticate — users must
--    update to the fixed build (1.5.0). Publish the new version right
--    after applying this script.
-- ============================================================

-- ---------- C1: block ALL direct SELECT on tool_users ----------
drop policy if exists "read own row"  on public.tool_users;
drop policy if exists "read anon"     on public.tool_users;
-- (no select policy left → anon can read NOTHING from tool_users)

-- ---------- C2: block ALL direct UPDATE on tool_users ----------
drop policy if exists "update last_seen" on public.tool_users;
drop policy if exists "update own row"   on public.tool_users;
-- (no update policy left → anon can change NOTHING in tool_users)

-- ---------- Activation / verify via SECURITY DEFINER RPC ----------
-- SECURITY DEFINER = runs with the function owner's rights (bypasses RLS),
-- but ONLY exposes these exact operations and ONLY returns safe fields.

-- Activate: verify username + key, refresh last_seen, bind machine_id
-- (binds ONLY when the row has no machine_id yet — device lock preserved).
create or replace function public.activate_license(
  p_username text, p_key text, p_machine_id text)
returns table (id uuid, username text, full_name text, is_admin boolean,
               expires_at timestamptz, is_blocked boolean, machine_id text)
language sql security definer volatile
set search_path = public
as $$
  update public.tool_users t
     set last_seen_at = now(),
         machine_id   = case when t.machine_id = '' or t.machine_id is null
                             then p_machine_id else t.machine_id end
   where lower(t.username) = lower(p_username) and t.activation_key = p_key
  returning t.id, t.username, t.full_name, t.is_admin, t.expires_at,
            t.is_blocked, t.machine_id;
$$;

-- Verify (by id): refresh last_seen, return the safe fields the app needs
-- for its live background re-check (expiry / blocked / device lock).
create or replace function public.verify_license(p_id uuid)
returns table (id uuid, username text, full_name text, is_admin boolean,
               expires_at timestamptz, is_blocked boolean, machine_id text)
language sql security definer volatile
set search_path = public
as $$
  update public.tool_users t
     set last_seen_at = now()
   where t.id = p_id
  returning t.id, t.username, t.full_name, t.is_admin, t.expires_at,
            t.is_blocked, t.machine_id;
$$;

-- Lightweight heartbeat (kept for future use / parity with the audit).
create or replace function public.refresh_license_seen(p_id uuid)
returns void
language sql security definer volatile
set search_path = public
as $$ update public.tool_users set last_seen_at = now() where id = p_id; $$;

grant execute on function public.activate_license(text, text, text) to anon;
grant execute on function public.verify_license(uuid)              to anon;
grant execute on function public.refresh_license_seen(uuid)        to anon;

-- ---------- C4: admin_config no longer anon-readable ----------
drop policy if exists "read admin config" on public.admin_config;
-- (the app's adminLogin() now reads the hash with the admin client)

-- ---------- C5: deactivate placeholder update rows ----------
update public.app_versions
   set is_active = false
 where download_url ilike '%placeholder%'
    or download_url ilike '%your-installer-link-here%';

-- ============================================================
-- VERIFY (run these as a sanity check):
--   -- these must now return ZERO rows for the anon role simulation:
--   select username, activation_key from public.tool_users limit 1;  -- via app anon key → 0 rows
--   select * from public.admin_config;                               -- via app anon key → 0 rows
--   -- these must still work:
--   select * from public.activate_license('someuser','SOME-KEY','machinelocalhash');
--   select version, is_active from public.app_versions order by published_at desc;
-- ============================================================
