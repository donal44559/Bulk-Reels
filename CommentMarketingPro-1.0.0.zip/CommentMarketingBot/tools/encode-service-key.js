#!/usr/bin/env node
// ============================================================
// Comment Marketing Pro — service key encoder helper
//
// The app stores the Supabase service (secret) key XOR-obfuscated in
// src/auth/supabaseClient.js (same scheme as the Reels tool).
// After creating the NEW Supabase project for this tool:
//
//   1) Copy the new project's service (secret) key
//      (Supabase Dashboard → Project Settings → API → service_role / secret key)
//   2) Run:   node tools/encode-service-key.js sb_secret_yourkeyhere
//   3) Paste the printed `const _S = [...]` line into
//      src/auth/supabaseClient.js (replacing the placeholder array)
// ============================================================

const _K = 'BRUP-2026-EusufHasan-Munna-BulkReels-Pro-Automation-Tools-Secret';

const key = String(process.argv[2] || '').trim();
if (!key) {
  console.error('Usage: node tools/encode-service-key.js <your-service-key>');
  console.error('Example: node tools/encode-service-key.js sb_secret_abcd1234...');
  process.exit(1);
}
const _S = [...key].map((c, i) => c.charCodeAt(0) ^ _K.charCodeAt(i % _K.length));
console.log('Paste this into src/auth/supabaseClient.js (replace the existing _S array):\n');
console.log('const _S = [' + _S.join(',') + '];\n');
// Self-check: decode and confirm round-trip
const back = [..._S].reduce((out, v, i) => out + String.fromCharCode(v ^ _K.charCodeAt(i % _K.length)), '');
console.log('Self-check decode:', back === key ? 'OK ✅' : 'FAILED ❌');
